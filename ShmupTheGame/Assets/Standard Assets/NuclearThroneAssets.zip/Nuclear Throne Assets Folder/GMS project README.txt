If you are double-clicking on the link inside the folder and getting this message: 
------

Fatal Error: Can't create/open/write to LOG file:

(C:\ProgramData\gamemaker_studio\E7C82D96...\TraceIDE.log)

This file and directory MUST be writeable by all users.
-----

Open up GameMaker:Studio, and load the project from the GMS start menu. It should work that way instead! 